-- Kamaji_Data.ms
struct KScene
(
    projectRoot = "",
    scenePath   = "",
    units       = #( #display: "metric", #system: "meters" ),
    fps         = 24,
    frameStart  = 1000,
    frameEnd    = 1050,
    resolution  = #(1920,1080),
    pixelAspect = 1.0,
    colorMode   = #ACES, -- #ACES or #Legacy
    notes       = ""
)

struct KCamera
(
    name        = "cam_main",
    focal       = 35.0,
    filmWidth   = 36.0,
    filmHeight  = 24.0,
    overscan    = 1.0,
    dofEnabled  = false,
    sourcePath  = "",         -- FBX/Alembic from Hiero
    distortion  = #( #mode:#undistorted, #stmapPath:"" ) -- #undistorted/#redisort
)

struct KPlate
(
    platePath   = "",         -- sequence or mov
    firstFrame  = 1000,
    lastFrame   = 1050,
    proxyPath   = "",
    retime      = #( #mode:#none, #map:#() ), -- e.g. time-warp pairs
    colorspace  = "Rec.709",  -- or "ACES - ACEScg" for metadata
    backgroundInViewport = true
)

struct KRender
(
    renderer      = #VRay,
    aovPack       = "studio_default",      -- link to a template
    outputPath    = "",                    -- EXR dir
    fileNameToken = "<SEQ>_<SHOT>_<LAYER>.<####>.exr",
    bitDepth      = 16,
    compression   = "zip",
    deadline      = #( #use:true, #pool:"3d", #priority:50, #group:"vray" )
)

struct KPreview
(
    enable       = true,
    codec        = "H264",
    outPath      = "",
    burnins      = #( #shot:true, #frame:true, #version:true ),
    quality      = #medium
)

struct KShot
(
    seq       = "AA",
    shot      = "0010",
    version   = "v001",
    uid       = "",              -- optional GUID
    scene     = KScene(),
    camera    = KCamera(),
    plate     = KPlate(),
    render    = KRender(),
    preview   = KPreview()
)

struct KamajiData
(
    shots      = #(),            -- array of KShot
    activeShot = undefined,      -- KShot

    setActiveShot = function idx:1 do
    (
        if shots.count >= idx then activeShot = shots[idx]
        else activeShot = undefined
        activeShot
    ),

    addShot = function kshot do append shots kshot
)
